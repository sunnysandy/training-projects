var express=require("express");
var path = require('path');
var bodyParser=require("body-parser");
var session = require('express-session');
var mongoose = require('mongoose');
var passport = require('passport')
  , LocalStrategy = require('passport-local').Strategy;
var Schema=mongoose.Schema;
var ObjectId=Schema.ObjectId;
var User=mongoose.model('User',new Schema({
    id:ObjectId,
    email:{type:String,Unique:true},
    Password:String
}))
var app=express();
var router = express.Router();

//middle wires

//connect to mongoose
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/Newlogin');

app.use("/public",express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

app.get("/",function(req,res){
    res.sendFile(__dirname+"/public/views/loginpage.html");
})
app.get("/login",function(req,res){
  res.sendFile(__dirname+"/public/views/loginpage.html");
})
app.get("/register",function(req,res){
  res.sendFile(__dirname+"/public/views/register.html");
})
app.get("/dashboard",function(req,res){
  res.sendFile(__dirname+"/public/views/dashboard.html");
})
app.post("/login",function(req,res){
  User.findOne({email:req.body.emailid},function(err,user){
    if(!user){
      console.log(err)
      res.send({status:"NotOK",msg:"Invalid Email id",url:"/login"});
    }
    else {
      if(req.body.password===user.Password){
        res.send({status:"OK",msg:"Sucess login",url:"/dashboard"});
      }else{
            res.send({status:"NotOK",msg:"Invalid Password",url:"/login"});
          }
    }
  });
});
app.post("/register",function(req,res){
var user=new User({
  email:req.body.emailid,
  Password:req.body.password
})
user.save(function(error){
  if(error){
    console.log("error: "+error)
    if(error.code==11000){
      res.send("Email id is already existing..")
    }
  }else{
    res.json({ok:"ok",userName:user})
  }

})
  //res.json(req.body);
});

app.listen(401,function(){
  console.log("runing mean at 401")
})
