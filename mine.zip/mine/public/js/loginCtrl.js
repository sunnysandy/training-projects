var app=angular.module("LoginApp",[]);
app.controller("loginCtrl",function(){
  console.log("I am from loginCtrl")
})
