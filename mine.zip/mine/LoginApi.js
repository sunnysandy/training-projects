module.export.getUserByname=function(username,callback){
  var query={username:username};
  user.find()

}
